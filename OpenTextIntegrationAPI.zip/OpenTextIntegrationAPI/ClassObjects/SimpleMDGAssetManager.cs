﻿namespace OpenTextIntegrationAPI.ClassObjects
{
    public class SimpleMDGAssetManager
    {
    }
}
