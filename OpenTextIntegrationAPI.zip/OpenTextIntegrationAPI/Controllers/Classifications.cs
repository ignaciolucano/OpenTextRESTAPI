﻿namespace OpenTextIntegrationAPI.Controllers
{
    public class Classifications
    {
    }
}
