using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OpenTextIntegrationAPI.LogAnalyzer.Views.LogAnalyzer
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
