﻿namespace OpenTextIntegrationAPI.Models
{
    // DTO used for update response payload
    public class ChangeRequestUpdateResponse
    {
        public string Message { get; set; }
        // You can add additional response properties if needed
    }
}
