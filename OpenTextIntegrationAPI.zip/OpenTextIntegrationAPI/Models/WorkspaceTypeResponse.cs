﻿namespace OpenTextIntegrationAPI.Models
{
    public class WorkspaceTypeResponse
    {
        public int id { get; set; }
        public bool isLinked { get; set; }
        public int type { get; set; }
        public int workspace_type_id { get; set; }
    }
}
